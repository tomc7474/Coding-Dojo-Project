from flask import render_template, request, redirect, session, flash, url_for
from flask_app import app
from flask_app.models.recipe import Recipe
from flask_app.models.user import User
from flask_app.models.comment import Comment
from flask_app.config.mysqlconnection import connectToMySQL

@app.route('/recipe/new')
def new_recipe():
    if 'user_id' not in session:
        return redirect('/logout')
    data = {"id":session['user_id']}
    return render_template('new.html', user = User.user_id(data))

@app.route('/recipe/create', methods=['POST'])
def create_recipe():
    if 'user_id' not in session:
        return redirect('/logout')
    if not Recipe.validate_recipe(request.form):
        return redirect('/recipe/new')
    data = {
        "name": request.form["name"],
        "description": request.form["description"],
        "ingredients": request.form["ingredients"],
        "instructions": request.form["instructions"],
        "time": int(request.form["time"]),
        "date_made": request.form["date_made"],
        "user_id": session["user_id"]
    }
    Recipe.save(data)
    return redirect('/dashboard')

@app.route('/recipe/edit/<int:id>')
def edit_recipe(id):
    if 'user_id' not in session:
        return redirect('/logout')
    data = {"id":id}
    user_data = {"id":session['user_id']}
    return render_template('edit.html', recipe = Recipe.get_one(data), user = User.user_id(user_data), users = User.get_all())

@app.route('/recipe/update', methods=["POST"])
def update_recipe():
    if 'user_id' not in session:
        return redirect('/logout')
    if not Recipe.validate_recipe(request.form):
        return redirect('/recipe/new')
    data = {
        "name" : request.form['name'],
        "description" : request.form['description'],
        "ingredients": request.form["ingredients"],
        "instructions" : request.form['instructions'],
        "time" : int(request.form['time']),
        "date_made" : request.form['date_made'],
        "id" : request.form['id']
    }
    Recipe.update(data)
    return redirect('/dashboard')

@app.route('/recipe/<int:id>')
def show_recipe(id):
    if 'user_id' not in session:
        return redirect('/logout')
    data = {"id":id}
    user_data = {"id":session['user_id']}
    return render_template('show.html', recipe = Recipe.get_one(data), user = User.user_id(user_data), users = User.get_all())

@app.route('/recipe/<int:id>/like')
def like(id):
    if 'user_id' not in session:
        return redirect('/logout')
    query = "SELECT * FROM recipe; INSERT INTO likes (user_id, recipe_id) VALUES (%(user_id)s, %(recipe_id)s); UPDATE (recipe) SET likes = likes + 1 WHERE id=(%(recipe_id)s)"
    data = {
        'user_id': session['user_id'],
        'recipe_id': id
    }
    mysql = connectToMySQL('recipes_erd')
    mysql.query_db(query, data)
    return redirect('/dashboard')

@app.route('/recipe/delete/<int:id>')
def destroy(id):
    if 'user_id' not in session:
        return redirect('/logout')
    data = {"id":id}
    Recipe.destroy(data)
    return redirect('/dashboard')

@app.route('/create/comment', methods=['POST'])
def create_comment():
    if 'user_id' not in session:
        return redirect('/logout')
    user_data = {"id":session['user_id']}
    if not Comment.validate_comment(request.form):
        return redirect('/show/1')
    data = {"id":session['user_id']}
    data = {
        "content": request.form["content"],
        "user_id": session["user_id"],
        
    }
    Comment.save(data)
    return redirect('/recipe/1')
