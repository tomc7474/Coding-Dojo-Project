from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash

class Comment:
    database = "recipes_erd"
    def __init__(self, data):
        self.id = data['id']
        self.content = data['content']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.user_id = data['user_id']
        self.recipe_id = data['recipe_id']

    @classmethod
    def save(cls,data):
        query = "INSERT into comment (content, user_id, recipe_id) VALUES (%(content)s, %(user_id)s, %(recipe_id)s);"
        return connectToMySQL(cls.database).query_db(query,data)

    @classmethod
    def get_all(cls):
        query = "SELECT * FROM comment;"
        results = connectToMySQL(cls.database).query_db(query)
        comments = []
        for r in results:
            comments.append(cls(r))
        return comments

    @classmethod
    def get_one(cls, data):
        query = "SELECT * FROM comment WHERE id = %(id)s;"
        results = connectToMySQL(cls.database).query_db(query,data)
        return cls(results[0])

    @classmethod
    def update(cls, data):
        query = "UPDATE comment SET content=%(content)s, updated_at=NOW() WHERE id = %(id)s;"
        return connectToMySQL(cls.database).query_db(query,data)

    @classmethod
    def destroy(cls,data):
        query = "DELETE FROM comment WHERE id = %(id)s;"
        return connectToMySQL(cls.database).query_db(query,data)

    @staticmethod
    def validate_comment(comment):
        is_valid = True
        if len(comment['content']) < 1:
            flash("Must say something to comment!")
            is_valid=False
        return is_valid