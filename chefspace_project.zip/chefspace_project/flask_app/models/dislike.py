from flask_app.config.mysqlconnection import connectToMySQL

class Dislike:
    database = "recipes_erd"
    def __init__(self, data):
        self.id = data['id']
        self.disliked = data['disliked']
        self.user_id = data['user_id']
        self.recipe_id = data['recipe_id']
        
    @classmethod
    def save(cls,data):
        query = "INSERT INTO dislikes (user_id, recipe_id, disliked) VALUES (%(user_id)s, %(recipe_id)s, 1);"
        return connectToMySQL(cls.database).query_db(query,data)

    @classmethod
    def get_all(cls):
        query = "SELECT * FROM dislikes;"
        recipes_db = connectToMySQL('recipes_erd').query_db(query)
        dislikes = []
        for d in recipes_db:
            dislikes.append(cls(d))
        return dislikes

    @classmethod
    def get_count(cls, data):
        query = "SELECT COUNT(recipe_id) FROM dislikes WHERE recipe_id = %(id)s;"
        recipes_db = connectToMySQL(cls.database).query_db(query, data)
        string_db = str(recipes_db)
        newList = list(string_db)
        newStr = ""
        for w in newList:
            if w.isdigit():
                newStr = newStr + w
        return newStr

    @classmethod
    def get_count_user(cls, data):
        query = "SELECT COUNT(recipe_id) FROM dislikes WHERE recipe_id = %(id)s AND user_id = %(user_id)s;"
        recipes_db = connectToMySQL(cls.database).query_db(query, data)
        string_db = str(recipes_db)
        newList = list(string_db)
        newStr = ""
        for w in newList:
            if w.isdigit():
                newStr = newStr + w
        return int(newStr)

    @classmethod
    def destroy(cls,data):
        query = "DELETE FROM dislikes WHERE id = %(id)s;"
        return connectToMySQL(cls.database).query_db(query,data)