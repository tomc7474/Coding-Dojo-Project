from flask_app.models import user
from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash

class Recipe:
    def __init__(self, data):
        self.id = data['id']
        self.name = data['name']
        self.description = data['description']
        self.ingredients = data['ingredients']
        self.instructions = data['instructions']
        self.time = data['time']
        self.date_made = data['date_made']
        self.likes = data['likes']
        self.user_id = data['user_id']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']

    @classmethod
    def save(cls,data):
        query = "INSERT into recipe (name, description, ingredients, instructions, time, date_made, likes, user_id) VALUES (%(name)s, %(description)s, %(ingredients)s, %(instructions)s, %(time)s, %(date_made)s, 0, %(user_id)s);"
        return connectToMySQL('recipes_erd').query_db(query,data)

    @classmethod
    def get_all(cls):
        query = "SELECT * FROM recipe;"
        recipes_db = connectToMySQL('recipes_erd').query_db(query)
        recipes = []
        for r in recipes_db:
            recipes.append(cls(r))
        return recipes

    @classmethod
    def get_one(cls,data):
        query = "SELECT * FROM recipe WHERE id = %(id)s;"
        results = connectToMySQL('recipes_erd').query_db(query,data)
        return cls(results[0])

    @classmethod
    def update(cls,data):
        query = "UPDATE recipe SET name=%(name)s, description=%(description)s, ingredients=%(ingredients)s, instructions=%(instructions)s, time=%(time)s, date_made=%(date_made)s, updated_at=NOW() WHERE id = %(id)s;"
        return connectToMySQL('recipes_erd').query_db(query,data)

    @classmethod
    def destroy(cls,data):
        query = "DELETE FROM recipe WHERE id = %(id)s;"
        return connectToMySQL('recipes_erd').query_db(query,data)


    @classmethod
    def dislike(cls,data):
        query = "UPDATE recipe SET likes = likes - 1 WHERE id = %(id)s;"
        return connectToMySQL('recipes_erd').query_db(query,data)

    @staticmethod
    def validate_recipe(recipe):
        is_valid = True
        if recipe['name'] == '':
            flash("Must have a name!")
            is_valid=False
        if recipe['date_made'] == '':
            flash("Must have a date!")
            is_valid=False
        if recipe['time'] == '':
            flash("Must have a time!")
            is_valid=False
        if recipe['description'] == '':
            flash("Must have description!")
            is_valid=False
        if len(recipe['description']) < 5:
            flash("Description must be at least 5 characters!")
            is_valid=False
        if recipe['ingredients'] == '':
            flash("Must have ingredients!")
            is_valid=False
        if recipe['instructions'] == '':
            flash("Must have a recipe!")
            is_valid=False
        elif len(recipe['instructions']) < 30:
            flash("Instructions must be at least 20 characters!")
            is_valid=False
        return is_valid